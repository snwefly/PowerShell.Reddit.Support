# Small Form with function Calling

Run by running script like so

```
    ./Run.ps1
```